import { NavLink } from "react-router-dom";

export default function Navbar(){
  return (
    <nav 
      className="flex flex-row justify-between items-center h-16 w-full sticky z-20 bg-gray-300 px-12"
    >
        <NavLink to="" className="flex flex-row justify-center items-center gap-2">
          <img src="/assets/logo-estuaire.png" alt="logo" className="w-12" />
          <span className="lugrasimo-font font-bold">Estuaire Services</span>
        </NavLink>

        <NavLink to="">
          <ul className="flex flex-row justify-center items-center gap-8">
              <li className="font-semibold text-blue transition-all">
                <NavLink to="" >
                  Accueil
                </NavLink>
              </li>

              <li className="font-semibold hover:text-blue transition-all">
                <NavLink to="" >
                  A Propos
                </NavLink>
              </li>


              <li className="font-semibold hover:text-blue transition-all">
                <NavLink to="" >
                  Services
                </NavLink>
              </li>

              <li className="bg-blue py-2 px-5 text-white font-semibold hover:bg-transparent hover:border-[2px] hover:text-blue border-blue transition-all rounded-md">
                <NavLink to="" >
                  Obtenir un devis
                </NavLink>
              </li>
          </ul>
        </NavLink>
    </nav>
  )
}